/*********************************
* Class: MAGSHIMIM C2			 *
* Week:                			 *
* Name:                          *
* Credits:                       *
**********************************/

#include <stdio.h>

int main(void)
{
	int *p = NULL;
	printf("%p", p);  //the adress of the pointer -> the adrees is NULL - nothing
	printf("%d", *p); // the value - NULL [nothing]

	return 0;
}