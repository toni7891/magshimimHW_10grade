/*********************************
* Class: MAGSHIMIM C2			 *
* Week:                			 *
* Name:                          *
* Credits:                       *
**********************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define FALSE 0
#define TRUE !FALSE
#define TEXT "textCopy"
#define BINARY "binaryCopy"
#define ERROR_MESSAGE  "Invalid execution\nUsage: copyFile.exe (textCopy|binaryCopy) <sourceFile> <destinationFile>"

int validOption(char** argv, FILE** copyFrom);
void textCopy(FILE* inputFile, char* output);
int isExist(FILE* filename);
void binaryCopy(FILE* inputFile, char* output);

int ctoContinue = FALSE;

int main(int argc, char** argv)
{

	FILE* copyFrom = 0;
	if (argc == 4)
	{

		if (validOption(argv, &copyFrom))
		{
			ctoContinue = TRUE;
		}
		if (ctoContinue && copyFrom == NULL)
		{
			printf("%s file does not exist", argv[2]);
			ctoContinue = FALSE;
		}
	}
	else
	{
		printf("%s", ERROR_MESSAGE);
		ctoContinue = FALSE;
	}
	if (ctoContinue)
	{


		if (!strcmp(argv[1], TEXT))
		{
			textCopy(copyFrom, argv[3]);
		}
		else
		{
			binaryCopy(copyFrom, argv[3]);
		}
		fclose(copyFrom);


	}
	return 0;
}

int validOption(char** argv, FILE** copyFrom)
{
	if (!strcmp(argv[1], TEXT))
	{
		*copyFrom = fopen(argv[2], "r");
		return TRUE;
	}
	else if (!strcmp(argv[1], BINARY))
	{
		*copyFrom = fopen(argv[2], "rb");
		return TRUE;
	}

	else
	{
		printf("%s", ERROR_MESSAGE);
		return FALSE;
	}
}

void textCopy(FILE* inputFile, char* output)
{
	int currentCharacter = 0;
	FILE* check = fopen(output, "r");

	if (isExist(check))
	{
		FILE* outputFile = fopen(output, "w");
		do
		{
			currentCharacter = fgetc(inputFile);
			if (currentCharacter != -1)
			{
				fputc(currentCharacter, outputFile);
			}
		} while (currentCharacter != -1);
		fclose(outputFile);
		printf("Copy completed.");
	}

	if (check != NULL)
	{
		fclose(check);
	}
}

void binaryCopy(FILE* inputFile, char* output)
{
	char* arr = 0;
	int i = 0;
	FILE* check = fopen(output, "r");

	if (isExist(check))
	{
		FILE* outputFile = fopen(output, "wb");
		fseek(inputFile, 0, SEEK_END);
		int length = ftell(inputFile) * sizeof(char);
		arr = (char*)malloc(length);

		fseek(inputFile, 0, SEEK_SET);
		fread(arr, 1, length, inputFile);

		fseek(inputFile, 0, SEEK_SET);
		fwrite(arr, 1, length, outputFile);
		fclose(outputFile);
	}
	free(arr);

	if (check != NULL)
	{
		fclose(check);
	}

	printf("Copy completed.");
}

int isExist(FILE* filename)
{
	int choice = -1;

	if (!filename)
	{
		return TRUE;
	}

	else
	{
		printf("Do you want to overwrite? 0 (no) / 1 (yes)");
		scanf("%d", &choice);
		return choice;
	}
}